import React from "react";
import ViewerComponent from "../../elements/viewerCard";
import Button from "../../elements/button";
import HorizontalLine from "../../elements/horizontalLine";
import ViewerForm from "../../elements/viewerForm";
import { ViewerCard } from "../../elements/viewerCard";

function ViewerArea() {
  return (
    <>
      <div
        style={{
          display: "flex",
          flexDirection: "row",
        }}
      >
        <Button
          backgroundColor={"black"}
          title={"Key Images"}
          borderRadius="5px"
          fontWeight={400}
          width={110}
          marginLeft="172px"
          marginTop="15px"
          textColor={"white"}
          fontSize="2rem"
          padding="12px"
        />
        <Button
          backgroundColor={"rgb(139, 0, 58)"}
          title={"View Dicom"}
          borderRadius="5px"
          fontWeight={400}
          width={110}
          marginLeft="5px"
          marginTop="15px"
          textColor={"white"}
          fontSize="2rem"
          padding="12px"
        />
      </div>
      <HorizontalLine
        marginTop="5px"
        marginLeft="168px"
        borderTop="2px solid white"
        width="1265px"
      />
      <div
        style={{
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          gap: "0px",
        }}
      >
        <ViewerCard
          width="920px"
          height="600px"
          borderRadius="10px"
          boxShadow="0 4px 8px rgba(0, 0, 0, 0.1)"
          backgroundColor="#ffffff"
          marginLeft="167px"
        />
        <ViewerForm
          color="white"
          width="50vh"
          height="70vh"
          backgroundColor="black"
          alignItems="center"
          marginTop="-234px"
        />
      </div>
    </>
  );
}

export default ViewerArea;
