import React from 'react'

const Drag = () => {
  return (
    <div>Drag</div>
  )
}

export default Drag