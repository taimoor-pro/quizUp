import React from "react";
import { AiFillEye } from "react-icons/ai";

const Label = (props) => {
  const { text, color, fontFamily } = props;

  return (
    <div className="d-flex justify-content-between">
      <label
        htmlFor="label"
        style={{
          color: color ? color : "white",
          fontSize: "18px",
          fontWeight: "bold",
          fontFamily: fontFamily ? fontFamily : "Poppins sans-serif",
        }}
      >
        {text}
      </label>
    </div>
  );
};

export default Label;
