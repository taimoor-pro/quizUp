import React from "react";

const HorizontalLine = (props) => {
  const {
    title,
    textColor,
    fontSize,
    fontWeight,
    padding,
    fontFamily,
    textAlign,
    marginLeft,
    borderTop,
    margin,
    marginTop,
    color,
    border,
    width,
  } = props;

  return (
    <hr
      style={{
        borderTop: borderTop ? borderTop : "3px solid #555",
        margin: margin ? margin : "20px 0",
        marginTop: marginTop ? marginTop : "20px",
        width: width ? width : "auto",
        color: color ? color : "white",
        marginLeft: marginLeft ? marginLeft : "4px",
      }}
    />
  );
};

export default HorizontalLine;
