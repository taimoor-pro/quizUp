import React from "react";
import "./index.css";

const Button = (props) => {
  const {
    borderRadius,
    padding,
    margin,
    title,
    backgroundColor,
    textColor,
    width,
    borderColor,
    onClick,
    marginLeft,
    fontWeight,
    marginTop,
    fontSize,
  } = props;

  return (
    <button
      onClick={onClick ? onClick : () => {}}
      className="button-33"
      // className={`m-0 fs-xs ${nopadding ? "px-0" : "px-4"} ${padding && padding} `}
      style={{
        backgroundColor: backgroundColor ? backgroundColor : "white",
        color: textColor ? textColor : "black",
        fontSize: fontSize ? fontSize : "14px",
        //height: 52,
        padding: padding ? padding : "auto",
        width: width ? width : "265px",
        borderRadius: borderRadius ? borderRadius : "5px",
        // border: borderColor ? '2px solid' : 'none',
        fontWeight: fontWeight ? fontWeight : "normal",
        marginTop: marginTop ? marginTop : "0px",
        // borderColor: borderColor,
        // boxShadow: '5px 5px 40px grey',
        display: "flex",
        fontFamily: "Poppins",
        justifyContent: "center",
        alignItems: "center",
        whiteSpace: "nowrap",
        fontSize: "14px",
        lineHeight: "20px",
        padding: padding ? padding : "2px",
        marginLeft: marginLeft ? marginLeft : "0",
        // margin: margin ? margin : "0",
      }}
    >
      {title}
    </button>
  );
};

export default Button;
