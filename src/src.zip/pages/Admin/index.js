import React from "react";
import Navbar from "../../components/modules/Navbar";

import Dashboard from "../Dashboard";
import Input from "../../components/elements/Input";

import Heading from "../../components/elements/heading";
import FieldBar from "../../components/elements/FieldBar";
import NavBar from "../../components/modules/Navbar";
import CreateCase from "../../components/modules/CreateCase";

const Admin = () => {
  return (
    <>
      <CreateCase/>
    </>
  );
};

export default Admin;
