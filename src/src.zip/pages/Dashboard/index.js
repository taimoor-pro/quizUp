import React from 'react'
import Admin from '../Admin'
import User from '../User'

const Dashboard = () => {


  return (
    <>
     <Admin />
    </>
  )
}

export default Dashboard