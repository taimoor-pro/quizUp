import React from 'react'

const Home = () => {
  return (
    <div>My Home Page</div>
  )
}

export default Home