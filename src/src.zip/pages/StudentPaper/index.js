import React from "react";
import ViewerArea from "../../components/modules/ViewerArea";

const StudentPaper = () => {
  return (
    <>
      <ViewerArea />
    </>
  );
};

export default StudentPaper;
