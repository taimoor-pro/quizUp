import React from "react";
import DragDropFiles from "../../components/modules/Drag/DragDrop";

const CreateCase = () => {
  return (
    <>
      <div className="container">
        {/* <SortableList /> */}
        <DragDropFiles />
      </div>
    </>
  );
};

export default CreateCase;
